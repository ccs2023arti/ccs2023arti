import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.metrics import classification_report, accuracy_score
import joblib

# Step 1: Load the sample dataset, the sample dataset contains camera traffic from two different cameras. Each camera contains 800 traffic for each camera mode (4 different modes total)
# Total of 800*4*2 = 6400 traffic data
file_path = 'dataset.csv'
data = pd.read_csv(file_path, sep=',', header=None)  
# The labels correspond to the different camera modes (e.g., 'mode A = Normal Unpaid', B = 'Normal Paid', C = 'Live Unpaid', D = 'Live Paid')
X = data.iloc[:, :-1]  # features - all columns except the last one
# We are loading traffic data from the camera
y = data.iloc[:, -1]   # target - the last column which is pre-labeled

# Step 2: Preprocess the data
# Splitting data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Feature Scaling: Standardizing the data.
sc = StandardScaler()
X_train = sc.fit_transform(X_train)
X_test = sc.transform(X_test)

# Step 3: Train the SVM classifier
clf = SVC(kernel='rbf', decision_function_shape='ovo')  # 'ovo' for one-vs-one strategy in multi-class classification
clf.fit(X_train, y_train)

# Step 4: Evaluate the model
y_pred = clf.predict(X_test)

print("Classification Report:")
print(classification_report(y_test, y_pred))

print("Accuracy Score:", accuracy_score(y_test, y_pred))

# Step 5: Save the model and the scaler
# Save the model as a binary file
model_filename = 'svm_camera_modes_classifier.sav'
joblib.dump(clf, model_filename)

# Save the scaler as a binary file
scaler_filename = 'scaler.sav'
joblib.dump(sc, scaler_filename)

print(f"Model saved as {model_filename}")
print
